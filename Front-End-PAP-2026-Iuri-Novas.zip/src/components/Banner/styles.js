import styled from "styled-components";

export const Container = styled.div`
  padding: 180px 120px;
  position: relative;
  background-size: cover;
  background-position: center;
  background-image: url('https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80');
  display: flex;
  align-items: center;

  :before {
    background: linear-gradient(to right, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.3));
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
`;

export const Text = styled.div`
  width: 50%;
  position: relative;
  z-index: 2;

  h2 {
    color: var(--white);
    font-size: 58px;
    font-weight: 800;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
  }

  p {
    color: var(--white);
    font-size: 18px;
    margin-bottom: 20px;
    line-height: 1.6;
  }

  span {
    display: inline-block;
    background-color: var(--blue);
    border: none;
    color: var(--white);
    font-size: 16px;
    font-weight: 700; 
    padding: 14px 100px;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s ease-in-out;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);

    &:hover {
      background-color: #0044cc;
      transform: translateY(-2px);
    }
  }
`;
