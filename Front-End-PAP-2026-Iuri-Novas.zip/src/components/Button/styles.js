import styled from "styled-components";

export const Container = styled.button`
  width: 100%;
  cursor: pointer;
  display: inline-block;
  text-align: center;
  background-color: #d1a054;
  line-height: 24px;
  border: none;
  color: #ffffff;
  font-size: 0.875rem;
  font-weight: 700;
  padding: 14px 24px;
  border-radius: 6px;
  transition: all 0.3s ease-in-out;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);

  &:hover {
    background-color: #b88a44;
    transform: translateY(-2px);
    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
  }

  &:active {
    background-color: #a07638;
    transform: scale(0.98);
  }

  &:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
    box-shadow: none;
  }
`;
