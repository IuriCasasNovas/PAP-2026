import styled from "styled-components";

export const Container = styled.div`
  width: 100%;
  max-width: 280px;
  margin-bottom: 16px;
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: all 0.3s ease-in-out;

  &:hover {
    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
    transform: translateY(-5px);
  }
`;

export const Img = styled.div`
  width: 100%;
  height: 180px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease-in-out;
  }

  &:hover img {
    transform: scale(1.05);
  }
`;

export const Description = styled.div`
  padding: 16px;
  
  a {
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #d1a054;
    font-weight: 600;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #b88a44;
    }
  }

  h4 {
    font-size: 1rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 10px;
  }
`;

export const Itens = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  
  span {
    font-size: 0.875rem;
    color: #777;
  }
`;
