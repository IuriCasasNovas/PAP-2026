import styled from "styled-components";

export const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  padding: 80px 120px;
  background-color: #002244; /* Azul imobiliário elegante */
  color: #f8f9fa; /* Branco suave */
  border-top: 2px solid #d1a054; /* Dourado sofisticado */

  @media (max-width: 768px) {
    grid-template-columns: 1fr 1fr;
    padding: 60px 40px;
  }
`;

export const Item = styled.div`
  img {
    width: 180px;
  }

  h3 {
    margin-bottom: 10px;
    color: #d1a054; /* Dourado para destaque */
  }

  ul {
    list-style: none;
    padding: 0;
    
    li {
      padding: 10px 0;
      transition: color 0.3s;
      cursor: pointer;

      &:hover {
        color: #d1a054; /* Dourado imobiliário */
      }
    }
  }

  nav {
    display: flex;
    margin-top: 15px;
    
    li {
      display: flex;
      align-items: center;
      
      span {
        margin-right: 15px;
        transition: color 0.3s;
        cursor: pointer;

        &:hover {
          color: #d1a054;
        }
      }
    }
  }
`;

export const Copy = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 120px;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  background-color: #00172d; /* Tom mais escuro para separação visual */
  color: #f8f9fa;

  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
    padding: 20px 40px;
  }

  ul {
    display: flex;
    align-items: center;
    list-style: none;
    padding: 0;

    li {
      margin-left: 15px;
      cursor: pointer;
      transition: color 0.3s;

      &:hover {
        color: #d1a054;
      }
    }
  }
`
