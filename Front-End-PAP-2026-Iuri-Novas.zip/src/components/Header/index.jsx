import React from "react";
import { Link } from "react-router-dom";
import LogoImg from "../../assets/logo.png";
import { Container, Logo, Menu, LogoutButton } from "./styles";

const Header = () => {
  const handleLogout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  const userLogged = localStorage.getItem("Yt");

  return (
    <Container>
      <Logo>
        <Link to="/">
          <img src={LogoImg} alt="Logo" />
        </Link>
      </Logo>
      <Menu>
        <ul>
          {!userLogged ? (
            <li>
              <Link to="/login">Login</Link>
            </li>
          ) : (
            <li>
              <LogoutButton onClick={handleLogout}>Sair</LogoutButton>
            </li>
          )}
        </ul>
      </Menu>
    </Container>
  );
};

export default Header;
