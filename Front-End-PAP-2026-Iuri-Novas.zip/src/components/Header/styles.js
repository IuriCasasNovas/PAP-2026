import styled from "styled-components";

export const Container = styled.div`
  padding: 20px 120px;
  height: 90px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid #d1a054; /* Dourado sofisticado */
  background-color: #002244; /* Azul imobiliário elegante */
  position: sticky;
  top: 0;
  z-index: 1000;

  @media (max-width: 768px) {
    padding: 15px 40px;
    height: auto;
    flex-direction: column;
  }
`;

export const Logo = styled.div`
  display: flex;
  align-items: center;

  img {
    width: 220px;
    transition: transform 0.3s ease-in-out;

    &:hover {
      transform: scale(1.05);
    }
  }

  @media (max-width: 768px) {
    margin-bottom: 10px;
  }
`;

export const Menu = styled.nav`
  ul {
    display: flex;
    align-items: center;
    gap: 20px;
    list-style: none;
    padding: 0;

    @media (max-width: 768px) {
      flex-direction: column;
      gap: 12px;
    }
  }

  li {
    padding: 12px 18px;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 500;
    transition: all 0.3s ease-in-out;
    cursor: pointer;

    a {
      text-decoration: none;
      color: #f8f9fa; /* Branco suave */
      transition: all 0.3s ease-in-out;

      &:hover {
        color: #002244;
      }
    }

    &:hover {
      background-color: #d1a054; /* Dourado imobiliário */
      color: #002244; /* Azul escuro para contraste */
    }
  }
`;

export const LogoutButton = styled.button`
  background: transparent;
  border: none;
  color: #f8f9fa;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  padding: 12px 18px;
  border-radius: 8px;
  transition: all 0.3s ease-in-out;

  &:hover {
    background-color: #d1a054; /* Dourado imobiliário */
    color: #002244;
  }
`;
