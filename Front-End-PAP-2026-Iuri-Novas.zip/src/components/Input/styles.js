import styled from "styled-components";

export const Container = styled.input`
  height: 50px;
  padding: 12px 18px;
  border-radius: 8px;
  width: 100%;
  color: #333;
  font-size: 1rem;
  margin-bottom: 12px;
  outline: none;
  border: 1px solid #ccc;
  background-color: #f9f9f9;
  transition: all 0.3s ease-in-out;

  &:focus {
    border-color: #d1a054;
    background-color: #fff;
    box-shadow: 0 0 5px rgba(209, 160, 84, 0.5);
  }

  &::placeholder {
    color: #999;
  }
`;
