import styled from "styled-components";

export const Container = styled.div`
  padding: 60px 150px;
  position: relative;
  background-size: cover;
  background-position: center;
  background-image: url('https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1600&q=80');
  display: flex;
  align-items: center;
  justify-content: center;

  :before {
    background: linear-gradient(to right, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.3));
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
`;

export const Text = styled.div`
  width: 60%;
  text-align: center;
  position: relative;
  z-index: 2;

  h2 {
    color: var(--white);
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
  }

  p {
    color: var(--white);
    font-size: 1.2rem;
    margin-bottom: 20px;
    line-height: 1.6;
  }
`;
