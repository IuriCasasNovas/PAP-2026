import React, { Fragment, useState, useEffect } from "react";
import Card from "../../components/Card";
import Banner from "../../components/Banner";
import { Header, Wrapper } from "./styles";
import Api from "../../services/Api";

const Home = () => {
  const [imobi, setImobi] = useState([]);

  useEffect(() => {
    Api.get('/listimobi')
      .then((response) => {
        // Exibe a resposta no console para análise
        console.log("Resposta da API:", response.data);

        // Verifica se a resposta já é um array
        if (Array.isArray(response.data)) {
          setImobi(response.data);
        } else if (response.data.imoveis && Array.isArray(response.data.imoveis)) {
          // Caso a resposta seja um objeto com uma propriedade "imoveis"
          setImobi(response.data.imoveis);
        } else {
          console.error("Formato de dados inesperado:", response.data);
          setImobi([]); // Ou trate de outra forma a resposta inesperada
        }
      })
      .catch((error) => {
        console.error("Erro na requisição da API:", error);
      });
  }, []);

  return (
    <Fragment>
      <Banner />
      <Header>
        <h2>Find the property of your dreams!</h2>
      </Header>
      <Wrapper>
        {Array.isArray(imobi) && imobi.length > 0 ? (
          imobi.map(item => (
            <Card
              key={item.id}
              thumb={item.thumb}
              tipo={item.tipo}
              endereco={item.endereco}
              valor={item.valor}
              slug={item.slug}
            />
          ))
        ) : (
          <p>Dados não disponíveis</p>
        )}
      </Wrapper>
    </Fragment>
  );
};

export default Home;
