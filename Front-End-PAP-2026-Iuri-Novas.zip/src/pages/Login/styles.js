import styled from "styled-components";

export const Container = styled.div`
  padding: 100px 150px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;

  h2 {
    font-size: 1.875rem;
    color: #002244;
  }

  p {
    font-size: 1.2rem;
    margin-bottom: 15px;
    color: #555;
  }
`;

export const ContainerForm = styled.div`
  padding: 35px;
  width: 370px;
  background-color: var(--white);
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  text-align: center;
`;

export const Form = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 15px;
`;

export const Label = styled.div`
  display: flex;
  margin-bottom: 10px;
  font-weight: 500;
  color: #333;
`;

/* Botão "Criar Conta" */
export const RegisterButton = styled.div`
  margin-top: 20px;
  text-align: center;

  p {
    font-size: 0.9rem;
    color: #555;
    margin-bottom: 5px;
  }

  a {
    display: inline-block;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: bold;
    text-decoration: none;
    color: #fff;
    background-color: #d1a054;
    transition: background 0.3s ease-in-out;

    &:hover {
      background-color: #b58943;
    }
  }
`;
